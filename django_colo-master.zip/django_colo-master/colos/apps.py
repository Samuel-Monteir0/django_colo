from django.apps import AppConfig


class ColosConfig(AppConfig):
    name = 'colos'
